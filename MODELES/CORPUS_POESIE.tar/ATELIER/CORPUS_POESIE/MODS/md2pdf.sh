#!/bin/bash

if test -z $1
then echo -e "Syntaxe : $0 NOM";exit
fi

source CONF/atelier.ini

IN=ATELIER/${ATELIER}/SOURCE/source_${1}.md
OPT="Complète"
MODS=ATELIER/$ATELIER/MODS


# On (ré)génère l'en-tête PAPIER
if ${MODS}/entete_papier.sh
	then
	ET="ATELIER/${ATELIER}/SOURCE/ENTETE_PAPIER.md"
else
	echo -e "Une erreur est survenue dans la génération de l'en-tête papier...\n";exit 1
fi

# On applique les règles de la typographie française
sed -f ${MODS}/SED/typo_fr.sed ${IN} > ATELIER/$ATELIER/SOURCE/tempfr.md

if "$IMAGES"
	then echo -e "\nOption : en incorporant les images."
else
	echo -e "\nOption : sans images"
	cat ATELIER/${ATELIER}/SOURCE/tempfr.md > ATELIER/${ATELIER}/SOURCE/temp.md
	sed -f ${MODS}/SED/texte_sans_image.sed ATELIER/${ATELIER}/SOURCE/temp.md > ATELIER/${ATELIER}/SOURCE/tempfr.md
fi

# On applique les règles du corpus de poésie... LaTeX: package verse, etc.)
sed -f ${MODS}/SED/poesie.sed ATELIER/${ATELIER}/SOURCE/tempfr.md > ATELIER/${ATELIER}/SOURCE/pret.md

OUT=ATELIER/${ATELIER}/corpus_poesie__${1}.pdf

echo -e "\n Génération version papier en cours...\n Version : ${OPT}"
pandoc -s -V papersize:a4 -V geometry:margin=2.5cm $ET ATELIER/${ATELIER}/SOURCE/pret.md -o $OUT
echo "Génération terminée dans le dossier ATELIER/${ATELIER}."

exit 0


