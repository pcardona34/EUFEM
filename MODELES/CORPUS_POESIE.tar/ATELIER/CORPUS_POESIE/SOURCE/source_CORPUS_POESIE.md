
## A. Charles Baudelaire, _Les Fleurs du Mal_, « Sonnet d'automne », 1857

@CHAPO(Ce sonnet a été composé...)CHAPO@

@TITRE(Sonnet d’automne)TITRE@

@MESURE(– Sois charmante et tais-toi ! Mon cœur, que tout irrite)MESURE@

@POEME(
@STROPHE(
Ils me disent, tes yeux, clairs comme le cristal :@VERS
« Pour toi, bizarre amant, quel est donc mon mérite ? »@VERS   
– Sois charmante et tais-toi ! Mon cœur, que tout irrite,@VERS
Excepté la candeur de l’antique animal,
)STROPHE@

@STROPHE(
Ne veut pas te montrer son secret infernal,@VERS
Berceuse dont la main aux longs sommeils m’invite,@VERS
Ni sa noire légende avec la flamme écrite.@VERS
Je hais la passion et l’esprit me fait mal !
)STROPHE@

@STROPHE(
Aimons-nous doucement. L’Amour dans sa guérite,@VERS
Ténébreux, embusqué, bande son arc fatal.@VERS
Je connais les engins de son vieil arsenal :
)STROPHE@

@STROPHE(
Crime, horreur et folie ! – Ô pâle marguerite !@VERS
Comme moi n’es-tu pas un soleil automnal,@VERS
Ô ma si blanche, ô ma si froide Marguerite ?
)STROPHE@
)POEME@

## B. Victor Hugo, _Odes et ballades_, « À une jeune fille », 1826

@MESURE(Vous qui ne savez pas combien l'enfance est belle)MESURE@

@TITRE(À une jeune fille)TITRE@

@POEME(
@STROPHE(
Vous qui ne savez pas combien l'enfance est belle,@VERS
Enfant ! n'enviez point notre âge de douleurs,@VERS
Où le cœur tour à tour est esclave et rebelle,@VERS
Où le rire est souvent plus triste que vos pleurs.
)STROPHE@

@STROPHE(
Votre âge insouciant est si doux qu'on l'oublie !@VERS
Il passe, comme un souffle au vaste champ des airs,@VERS
Comme une voix joyeuse en fuyant affaiblie,@VERS
@INDENTE(Comme un alcyon sur les mers.
)STROPHE@
)POEME@
