## Amorce

> "Citation"

Auteur, _Titre_, AAAA

## Dossier de la partie X

+ **Document xx** : Auteur, _Titre_, AAAA
+ **Document xx** : Auteur, _Titre_, AAAA

## Document xx : Auteur, _Titre_ AAAA

+ Découverte du document
+ Analyse

---

### Remarque

Pour générer une section diaporama de chaque analyse, utilisez la génération automatique à partir d'un 
dossier d'images. Consultez l'aide des usages avancés.
