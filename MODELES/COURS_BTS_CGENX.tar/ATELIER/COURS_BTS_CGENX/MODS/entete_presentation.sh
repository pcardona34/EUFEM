#!/bin/bash

# On récupère les variables
source CONF/atelier.ini

for ini in ATELIER/${ATELIER}/INI/champs.ini
do
	if test -s $ini
	then
		source $ini
	else
		./menu.sh && exit
	fi
done

# Nom du fichier d'en-tête de la présentation
CIBLE=ATELIER/${ATELIER}/SOURCE/ENTETE_PRESENTATION.md


# On écrit l'en-tête
echo "% BTS-${NIVEAU_BTS} --- ${ACTIVITE} de ${MATIERE}  " > $CIBLE
echo "% ${THEME} (${NUM_PARTIE})  " >> $CIBLE
echo "% $(date +"%d %b %Y")  " >> $CIBLE
echo -e "\n#${NUM_PARTIE} - ${PARTIE}\n" >> $CIBLE
