# Titre de section : centré verticalement

## Titre de niveau 2

Sur la diapo, ce titre est placé en haut.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.

---

Nouvelle diapo après un saut de page `---` placé dans un passage de 
texte courant.

Ce saut disparaît dans la version papier.

# Début d'une nouvelle section

## Exemple de texte troué

Nulla facilisi @(etiam)@ dignissim diam quis enim lobortis scelerisque 
fermentum. Nisi scelerisque eu ultrices vitae auctor eu augue ut. 
Viverra suspendisse @(potenti)@ nullam ac. Id ornare arcu odio ut sem nulla 
pharetra diam. Semper viverra nam libero justo laoreet sit amet cursus. 
Sed velit dignissim sodales ut eu sem integer vitae justo.

Les trous ne sont visibles que dans la version papier et "trouée" de la 
publication.

 ---

### Cadre de mise en exergue

En mode présentation, cette mise en forme est bien adaptée pour une 
définition, une mise en garde, etc.
