
## A. Untel, _Titre_, AAAA

@CHAPO(Ceci est un texte-chapô...)CHAPO@

@NUM(Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. Odio pellentesque 
diam volutpat commodo sed egestas egestas fringilla phasellus. Porttitor 
eget dolor morbi non arcu. Mi eget mauris pharetra et ultrices neque 
ornare aenean. Id velit ut tortor pretium viverra suspendisse. Nullam 
non nisi est sit.)NUM@
